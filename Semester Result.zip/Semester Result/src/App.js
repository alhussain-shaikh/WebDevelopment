import logo from './logo.svg';
import './App.css';
import Result from './Result';

function App() {
  return (
     <>
      <Result />
     </>
  );
}

export default App;
